---
name: Neo-Cyber Analytics
colors:
  surface: '#0f1321'
  surface-dim: '#0f1321'
  surface-bright: '#353948'
  surface-container-lowest: '#090e1c'
  surface-container-low: '#171b2a'
  surface-container: '#1b1f2e'
  surface-container-high: '#252939'
  surface-container-highest: '#303444'
  on-surface: '#dfe1f6'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#dfe1f6'
  inverse-on-surface: '#2c303f'
  outline: '#849495'
  outline-variant: '#3b494b'
  surface-tint: '#00dbe9'
  primary: '#dbfcff'
  on-primary: '#00363a'
  primary-container: '#00f0ff'
  on-primary-container: '#006970'
  inverse-primary: '#006970'
  secondary: '#ffb1c3'
  on-secondary: '#66002c'
  secondary-container: '#ff4b89'
  on-secondary-container: '#590026'
  tertiary: '#fff6d1'
  on-tertiary: '#373100'
  tertiary-container: '#f3db00'
  on-tertiary-container: '#6b5f00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#7df4ff'
  primary-fixed-dim: '#00dbe9'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f54'
  secondary-fixed: '#ffd9e0'
  secondary-fixed-dim: '#ffb1c3'
  on-secondary-fixed: '#3f0019'
  on-secondary-fixed-variant: '#8f0041'
  tertiary-fixed: '#fde400'
  tertiary-fixed-dim: '#dec800'
  on-tertiary-fixed: '#201c00'
  on-tertiary-fixed-variant: '#504700'
  background: '#0f1321'
  on-background: '#dfe1f6'
  surface-variant: '#303444'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  metric-xl:
    fontFamily: JetBrains Mono
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.03em
  metric-xl-mobile:
    fontFamily: JetBrains Mono
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 32px
  metric-md:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
  body-lg:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-xs:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.08em
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes a high-velocity, mission-critical operational intelligence environment. Tailored for data engineers, executive analysts, and telemetry operators managing hyper-scale pipelines, it fuses the raw structural clarity of Neo-Brutalism with the high-contrast immersion of a futuristic cyber terminal.

The aesthetic combines deep void-like navy canvases with high-saturation neon strokes (cyan, pink, yellow, and laser red). Rather than leaning purely into retro tropes, the UI prioritizes hyper-legibility, precision framing, and functional density. High-contrast outlines define rigid boundaries, while translucent surface backdrops introduce spatial depth without compromising structural hierarchy. Interfaces must feel immediate, diagnostic, and uncompromisingly tactical.

## Colors

The palette operates in strict dark mode, anchored by deep space navies and ignited by neon visual markers.

- **Canvas & Backdrops:**
  - Base Canvas: `#070B19` (Absorptive deep navy)
  - Surface Tier 1 (Panel Background): `#0B112C` at 85% opacity with backdrop blur
  - Surface Tier 2 (Elevated Cells / Metric Plates): `#111A3E`
  - High-Stress Surface: `#1A0A16` (Used for critical fault states)

- **Chromatics & Outlines:**
  - **Electric Cyan (`#00F0FF`):** Primary directional focus, active states, key vector trends, and baseline telemetry metrics.
  - **Hot Pink (`#FF007A`):** Secondary delta metrics, comparative streams, and urgent categorical thresholds.
  - **Electric Yellow (`#FFE600`):** Warning states, anomalies, system alerts, and primary highlight nodes.
  - **Laser Red (`#FF1E44`):** Critical alerts, error ceilings, pipeline bottlenecks, and terminal drops.

- **Monochrome & Textures:**
  - Text Primary: `#FFFFFF`
  - Text Secondary: `#8A99AD`
  - Text Muted: `#4E5D78`
  - Structural Grid Border: `#1A264F`

## Typography

The typography couples the angular, architectural qualities of **Space Grotesk** with the strict, diagnostic precision of **JetBrains Mono**.

- **Display & Section Titles:** Rendered in Space Grotesk Bold. Use uppercase styling for dashboard headers and metric classifications to reinforce command-center ergonomics.
- **Data & Telemetry:** All numerical figures, runtimes, timestamps, and status IDs must strictly render in JetBrains Mono with tabular figures enabled. This guarantees column stability during real-time streaming updates.
- **Labels & Micro-copy:** Render in JetBrains Mono at 10px or 12px with wide tracking (`0.08em`) to mimic raw diagnostic instrument readouts.

## Layout & Spacing

The layout model implements a structured, modular fixed-fluid hybrid grid tailored for dense analytical panels and Power BI widget composition.

- **Desktop (1440px+):** 12-column dynamic framework with `1.5rem` (`24px`) gutters and `2rem` (`32px`) canvas boundary margins. Components snap to 4px sub-grid increments. Metric cards default to spans of 3 or 4 columns; timeline graphs and live topological clusters span 8 to 12 columns.
- **Tablet / Operational Display (768px - 1439px):** 8-column layout with `1rem` (`16px`) gutters. Secondary charts stack beneath primary KPIs.
- **Mobile Handheld (<768px):** 4-column column flow. Lateral scrolling is disabled; all widgets collapse into modular vertical stacks.
- **Density Control:** Keep inner card padding tightly locked between `space-sm` (`0.5rem`) and `space-md` (`1rem`) to maximize screen real estate and data visibility.

## Elevation & Depth

Depth in this system abandons soft, natural drop shadows in favor of a hybrid **Neo-Brutalist Glass** paradigm:

- **Surface Translucency:** Card and modal panels utilize dark translucent navies (`#0B112C` at 85% opacity) with `12px` to `16px` backdrop filters (`backdrop-filter: blur(14px)`).
- **Crisp Structural Borders:** Every container is circumscribed by a razor-sharp 1px or 1.5px high-contrast stroke. Default panels feature subtle structural blue strokes (`#1A264F`), which transition on active focus or threshold breach to `#00F0FF`, `#FF007A`, `#FFE600`, or `#FF1E44`.
- **Neon Hard Offsets & Cast Glows:** High-priority cards implement hard neo-brutalist shadow offsets (`3px 3px 0px 0px #00F0FF` or `#FF007A`) accompanied by an ultra-tight localized glow (`box-shadow: 0 0 12px rgba(0, 240, 255, 0.35)`). Low-priority containers cast zero diffuse blur.

## Shapes

The design system enforces a sharp `roundedness: 0` (0px radius) architecture across all core operational structural elements—cards, dialogs, charts, split-views, and data tables. This geometry reinforces an austere, analytical aesthetic.

The intentional exception is reserved for **Pill Badges** and status capsules (`border-radius: 9999px`). These rounded capsules visually contrast against the surrounding sharp modular grid, drawing immediate user focus to status markers and health metrics.

## Components

### Buttons & Interactive Triggers
- **Primary Action:** Sharp corners (0px), electric cyan background (`#00F0FF`), pure black text (`#000000`) in `Space Grotesk Bold`. Hard drop offset: `2px 2px 0px #FFFFFF`.
- **Secondary / Ghost Action:** Translucent dark canvas (`#0B112C`), 1px outline in `#00F0FF` or `#FF007A`, text matching stroke color. Hover states produce an instant inverted color fill with zero transition lag.

### Metric Cards & Telemetry Containers
- Built on dark glass surfaces (`#0B112C` with blur) encased in a 1px border (`#1A264F`).
- Card titles utilize uppercase JetBrains Mono with a left neon accent bar (2px width).
- Primary figures render in `metric-xl` monospaced type with real-time delta badges located at top-right.

### Status Badges & Pill Tags
- Fully pill-shaped (`9999px` radius) with a tight vertical padding (`2px 10px`).
- Colored outlines set to 1px with matching 20% opacity fills.
- Integrated neon indicator dot with a localized pulsing bloom effect for active feeds:
  - Nominal: `#00F0FF`
  - High Load: `#FFE600`
  - Critical / Incident: `#FF1E44`

### Data Tables & Stream Lists
- Rows have fixed heights (36px for dense views, 48px for standard views) separated by 1px rules (`#162044`).
- No zebra striping; row hover invokes a subtle cyan tint (`rgba(0, 240, 255, 0.05)`) with an electric yellow left indicator mark (2px).
- Headers remain locked to the viewport with an opaque navy fill (`#070B19`) and bold monospace micro-labels.

### Input Controls, Checkboxes & Toggles
- Inputs feature square frames, 1px `#1A264F` outlines, dark backdrops, and active focus rings consisting of a crisp 1px `#00F0FF` stroke paired with an ambient cyan glow.
- Checkboxes and radios are square with inset neon ticks or dot fills (`#00F0FF`).